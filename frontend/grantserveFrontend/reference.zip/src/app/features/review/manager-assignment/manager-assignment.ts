import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ManagerHeaderComponent } from '../../../shared/components/navigation/manager-header.component/manager-header.component';

@Component({
  selector: 'app-manager-assignment',
  standalone: true,
  imports: [CommonModule, FormsModule, ManagerHeaderComponent],
  templateUrl: './manager-assignment.html',
  styleUrls: ['./manager-assignment.css']
})
export class ManagerAssignmentComponent implements OnInit {
  applications = signal<any[]>([]);
  proposals = signal<any[]>([]);
  reviewers = signal<any[]>([]);

  selectedApplicationId: number | null = null;
  selectedProposalId: number | null = null;
  selectedReviewerId: number | null = null;

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchApplications();
    this.fetchReviewers();
  }

  fetchApplications() {
    this.http.get<any[]>('http://localhost:8081/application-service/GrantApplication/all').subscribe({
      next: (data) => {
        // Sort apps so that Approved ones go to the bottom if you like
        this.applications.set(data || []);
      },
      error: (err) => console.error("Error fetching apps:", err)
    });
  }

  fetchReviewers() {
    this.http.get<any[]>('http://localhost:8081/auth-service/auth/role/REVIEWER').subscribe({
      next: (data) => this.reviewers.set(data || []),
      error: (err) => console.error("Error fetching reviewers:", err)
    });
  }

  selectApplication(id: number) {
    this.selectedApplicationId = id;
    this.selectedProposalId = null; 
    this.selectedReviewerId = null;
    this.proposals.set([]); 

    this.http.get<any[]>(`http://localhost:8081/application-service/proposal/getProposal/${id}`).subscribe({
      next: (data) => this.proposals.set(data || []),
      error: (err) => console.error("Failed to load proposals", err)
    });
  }

  hasPendingProposals(): boolean {
    return this.proposals().some(p => p.status === 'SUBMITTED');
  }

  submitAssignment() {
    if (!this.selectedProposalId || !this.selectedReviewerId) return;

    const payload = {
      proposalId: Number(this.selectedProposalId),
      reviewerId: Number(this.selectedReviewerId),
      score: 0,
      comments: "Assigned by Manager.",
      date: new Date().toISOString().split('T')[0],
      status: 'UNDER_REVIEW'
    };

    this.http.post('http://localhost:8081/review-service/review/assign', payload, { 
      responseType: 'text' 
    }).subscribe({
      next: (response) => {
        alert('Proposal assigned successfully!');
        this.selectedApplicationId = null;
        this.fetchApplications(); 
      },
      error: (err) => alert('Assignment error. Check backend services.')
    });
  }
}