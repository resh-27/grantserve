import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { ReviewService } from '../service/review.service';

@Component({
  selector: 'app-review-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './review-form.component.html'
})
export class ReviewFormComponent implements OnInit {
  reviewData: any;
  score: number | null = null;
  comments: string = '';

  constructor(
    public router: Router, 
    private reviewService: ReviewService,
    private http: HttpClient
  ) {
    const navigation = this.router.getCurrentNavigation();
    this.reviewData = navigation?.extras.state?.['data'];
  }

  ngOnInit(): void {
    if (!this.reviewData) {
      this.router.navigate(['/reviewer-dashboard']);
      return;
    }

    // 1. Get the Proposal ID from the passed state
    const pid = this.reviewData.proposalID || this.reviewData.proposalId;

    // 2. Fetch the Proposal details from the other microservice to get the fileURI
    this.reviewService.getProposalById(pid).subscribe({
      next: (proposal) => {
        // Dynamically assign the fetched URI to our local object
        this.reviewData.fileURI = proposal.fileURI;
        console.log("Successfully fetched URI from Proposal Microservice:", this.reviewData.fileURI);
      },
      error: (err) => {
        console.error("Failed to fetch proposal details from microservice:", err);
      }
    });
  }

  viewDocument(url: string | undefined) {
    // If url is still undefined, it means the microservice call hasn't finished
    if (!url || url.trim() === "") {
      alert("Document link is still loading or could not be found in the Proposal service.");
      return;
    }

    console.log("Opening document:", url);
    window.open(url, '_blank');
  }

  submitReview() {
    if (!this.reviewData?.reviewID) return;

    const updatePayload = {
      proposalId: this.reviewData.proposalID || this.reviewData.proposalId,
      reviewerId: this.reviewData.reviewerID || this.reviewData.reviewerId,
      score: Number(this.score),
      comments: this.comments,
      status: 'REVIEWED',
      date: new Date().toISOString().split('T')[0] 
    };

    this.reviewService.updateReview(this.reviewData.reviewID, updatePayload).subscribe({
      next: () => {
        alert('Review Submitted successfully!');
        this.router.navigate(['/reviewer-dashboard']);
      },
      error: (err) => alert('Submission failed: ' + (err.error || 'Server error'))
    });
  }
}