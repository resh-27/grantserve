import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { LoginService } from '../services/login/login.service';

export const authGuard: CanActivateFn = (route, state) => {
  const loginService = inject(LoginService);
  const router = inject(Router);

  const allowedRoles = route.data['roles'] as string[];
  const userRole = localStorage.getItem('userRole');

  if (allowedRoles && userRole && allowedRoles.includes(userRole)) {
    return true;
  }


  if (loginService.isLoggedIn()) {
    return true;
  } else {
    return router.parseUrl('/');
  }
};
